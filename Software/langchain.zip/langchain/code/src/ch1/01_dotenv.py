from dotenv import load_dotenv
from dotenv import dotenv_values
import os

# load .env file
load_dotenv()

# load specific environment variables
# load_dotenv(dotenv_path='/path/to/first/.env')
# load_dotenv(dotenv_path='/path/to/second/.env')

# get environment variables
aoai_key = os.getenv("AOAI_API_KEY")

print(f"AOAI key: {aoai_key}") 

config = dotenv_values(".env")
print(config.get("AOAI_API_KEY"))
print(config.get("AZURE_OPENAI_ENDPOINT"))
print(config.get("AZURE_OPENAI_DEPLOYMENT_NAME"))
print(config.get("AZURE_OPENAI_API_VERSION"))
print(config.get("AZURE_OPENAI_KEY"))
