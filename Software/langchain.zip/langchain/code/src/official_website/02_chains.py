import os
from langchain_openai import AzureChatOpenAI
from langchain_core.output_parsers import StrOutputParser
from langchain_core.prompts import ChatPromptTemplate
from dotenv import dotenv_values
import asyncio

async def chains_example():
    config = dotenv_values(".env")

    # 初始化 Azure OpenAI LLM
    model = AzureChatOpenAI(
        azure_endpoint=config.get("AZURE_OPENAI_ENDPOINT"),
        azure_deployment=config.get("AZURE_OPENAI_DEPLOYMENT_NAME"),
        openai_api_version=config.get("AZURE_OPENAI_API_VERSION"), 
        api_key=config.get("AZURE_OPENAI_KEY"),
        temperature=0.5) 

    # create a prompt template and a parser
    prompt = ChatPromptTemplate.from_template("Please give me information about {topic}, in 100 words. ")
    parser = StrOutputParser()
    chain = prompt | model | parser

    chunks = []
    async for chunk in chain.astream({"topic": "Apple company"}):
        chunks.append(chunk)
        print(chunk, end="|", flush=True)
    

    print("\n")
    print("".join(chunks))
    print("\n")


# Call the async chains example
asyncio.run(chains_example())

