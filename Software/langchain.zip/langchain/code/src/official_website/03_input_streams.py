
import os
from langchain_openai import AzureChatOpenAI
from langchain_core.output_parsers import StrOutputParser
from langchain_core.output_parsers import JsonOutputParser
from langchain_core.prompts import ChatPromptTemplate
from dotenv import dotenv_values
import asyncio

async def input_streams_example():
    config = dotenv_values(".env")

    # 初始化 Azure OpenAI LLM
    model = AzureChatOpenAI(
        azure_endpoint=config.get("AZURE_OPENAI_ENDPOINT"),
        azure_deployment=config.get("AZURE_OPENAI_DEPLOYMENT_NAME"),
        openai_api_version=config.get("AZURE_OPENAI_API_VERSION"), 
        api_key=config.get("AZURE_OPENAI_KEY"),
        temperature=0.5) 

    chain = (
        model | JsonOutputParser()
    )  # Due to a bug in older versions of Langchain, JsonOutputParser did not stream results from some models
    async for text in chain.astream(
        "output a list of the countries france, spain and japan and their populations in JSON format. "
        'Use a dict with an outer key of "countries" which contains a list of countries. '
        "Each country should have the key `name` and `population`"
    ):
        print(text, flush=True)    

    # print("\n")
    # print("".join(chunks))
    # print("\n")


# Call the basic json output parser example
# asyncio.run(input_streams_example())


# Generator Function example

async def _extract_country_names_streaming(input_stream):
    """A function that operates on input streams."""
    country_names_so_far = set()

    async for input in input_stream:
        if not isinstance(input, dict):
            continue

        if "countries" not in input:
            continue

        countries = input["countries"]

        if not isinstance(countries, list):
            continue

        for country in countries:
            name = country.get("name")
            # population = country.get("population")
            # print(country.get("population"))
            # print(country)
            if not name:
                continue
            if name not in country_names_so_far:
                yield name
                # yield f'{name}-{population}' 
                country_names_so_far.add(name)


async def input_streams_with_generator_functions_example():
    config = dotenv_values(".env")

    # 初始化 Azure OpenAI LLM
    model = AzureChatOpenAI(
        azure_endpoint=config.get("AZURE_OPENAI_ENDPOINT"),
        azure_deployment=config.get("AZURE_OPENAI_DEPLOYMENT_NAME"),
        openai_api_version=config.get("AZURE_OPENAI_API_VERSION"), 
        api_key=config.get("AZURE_OPENAI_KEY"),
        temperature=0.5) 

    chain = (
        model | JsonOutputParser() | _extract_country_names_streaming
    )  # Due to a bug in older versions of Langchain, JsonOutputParser did not stream results from some models
    async for text in chain.astream(
        "output a list of the countries france, spain and japan and their populations in JSON format. "
        'Use a dict with an outer key of "countries" which contains a list of countries. '
        "Each country should have the key `name` and `population`"
    ):
        print(text, end="|", flush=True)    


asyncio.run(input_streams_with_generator_functions_example())
