import os
from langchain_openai import AzureChatOpenAI
from dotenv import dotenv_values
import asyncio
config = dotenv_values(".env")

# 初始化 Azure OpenAI LLM
# https://python.langchain.com/api_reference/openai/chat_models/langchain_openai.chat_models.azure.AzureChatOpenAI.html
model = AzureChatOpenAI(
    azure_endpoint=config.get("AZURE_OPENAI_ENDPOINT"),
    azure_deployment=config.get("AZURE_OPENAI_DEPLOYMENT_NAME"),
    openai_api_version=config.get("AZURE_OPENAI_API_VERSION"), 
    api_key=config.get("AZURE_OPENAI_KEY"),
    temperature=0.5) 

# sync stream API
chunks = []
for chunk in model.stream("what color is the sky?"):
    chunks.append(chunk)
    print(chunk.content, end="|", flush=True)

print("\n")
print(chunks[0])
print("\n")


async def astream_example(model):
    # async stream API
    chunks = []
    async for chunk in model.astream("what color is the sky?"):
        chunks.append(chunk)
        print(chunk.content, end="|", flush=True)

    print("\n")
    print("".join(chunk.content for chunk in chunks))
    print("\n")

# Call the async stream example
asyncio.run(astream_example(model))